# DDS DSL

An extension to QoS DSL that adds concepts, editors, and constraints to ensure a valid profile in the DDS middleware. This extension only extend capability profiles. 

### Dependencies
* [QoS DSL](https://github.com/rosym-project/qos-dsl): A small configuration language for the defition of communication QoS capabilities and requirements.

This language was created with [JetBrains' MPS](https://www.jetbrains.com/mps/). 
